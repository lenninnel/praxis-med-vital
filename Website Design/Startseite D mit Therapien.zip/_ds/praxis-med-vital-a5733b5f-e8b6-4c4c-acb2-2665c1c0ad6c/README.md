# Konventionen — Praxis Med Vital (Warm Minimal)

Klassisches CSS-Klassen-System, kein Framework, kein Provider/Wrapper nötig. `styles.css` bringt Reset, Tokens (`:root`-Custom-Properties), selbst gehostete Fonts (Cormorant Garamond + Jost) und das komplette Klassen-Vokabular mit. Der `body` bekommt automatisch Jost 300 / 15px auf `--cream`-Grund; Headlines (`h1–h6`) sind automatisch Cormorant Garamond kursiv.

## Styling-Idiom

Vorhandene Klassen verwenden, eigenes Layout-Glue mit `var(--*)`-Tokens stylen. Keine neuen Farbwerte erfinden — nur Tokens:

- **Kern-Palette:** `--cream #f5f0e8` (Grund), `--ink #1a100a` / `--ink-mid` / `--ink-lt` (Text), `--sage #6b5c4a` (Warm Stone — dunkle Flächen; der Name ist historisch, der Wert ist Braun, nicht Grün), `--stone #5a4d42` (Footer), `--white`, `--cream-dk`, `--border` (Hairlines).
- **Akzent:** `--gold #c4a05a`, auf dunklen Flächen `--gold-lt`. Nur als feine Linie/Detail, nie als Fläche.
- **Nicht verwenden (Legacy):** `--g900`–`--g50`, `--amber`, `--amber-dk`, Klasse `.sec--g900`.

Klassen-Vokabular (Auszug — vollständig in `styles.css`):

| Familie | Klassen |
|---|---|
| Sektionen | `.sec` + Modifier `.sec--cream`, `.sec--cream-dk`, `.sec--white`, `.sec--sage`, `.sec--stone`, `.sec--sage-lt`, `.sec--stone-lt` (dunkle Modifier stylen `.section-title`/`.section-sub`/`.eyebrow` automatisch um) |
| Überschriften-Muster | `.eyebrow` (uppercase-Label mit Goldlinie), `.section-title`, `.section-sub`, `.text-center` |
| Buttons | `.btn-primary`, `.btn-ghost`, `.btn-outline` (+ `--dark`-Varianten) |
| Karten | `.team-card` (+ `__avatar`, `__name`, `__role`, `__bio`), `.leistung-card` (+ `__num`, `__title`, `__desc`, `__items`), `.standort-card`, `.feature` (für dunkle Sektionen) |
| Grids | `.team-grid`, `.leistung-grid`, `.card-grid`, `.features-grid`, `.two-col`, `.contact-grid`, `.container` |
| Formulare | `.contact-form`, `.form-group`, `.full`, `.contact-form-wrap` |
| Seiten-Bausteine | `.page-header`, `.hero` (+ `__content`, `__title`, `__sub`, `__actions`, `__tel`), `.trust-bar`, `.site-header`/`.nav`, `.site-footer`/`.footer-grid`, `.hours-table`, `.tag-list`/`.tag`, `.back-link`, `.coming-soon` |

## Formregeln

`border-radius: 0` überall (Ausnahme: runde Avatare). Rahmen als 0.5px-Hairlines in `--border`. Kartenraster mit `gap:1px` auf `--border`-Hintergrund. Headlines kursiv, einzelne Wörter per `<em>` (wird in `.hero__title` automatisch gold). Labels uppercase mit `letter-spacing: .1em–.22em`.

## Wahrheitsquelle

Vor dem Stylen `styles.css` lesen (vollständiges Vokabular + Tokens), `tokens/tokens.json` (Token-Referenz mit Verwendungszweck) und `guidelines/design-language.md` (Design-Sprache).

## Idiomatisches Beispiel

```html
<section class="sec sec--cream-dk">
  <div class="container">
    <span class="eyebrow">Unsere Leistungen</span>
    <h2 class="section-title">Therapie, die <em>wirkt</em></h2>
    <p class="section-sub">Individuell abgestimmte Behandlung an zwei Standorten.</p>
    <div class="leistung-grid" style="margin-top:48px">
      <div class="leistung-card">
        <div class="leistung-card__num">01</div>
        <h3 class="leistung-card__title">Manuelle Therapie</h3>
        <p class="leistung-card__desc">Gezielte Mobilisation von Gelenken und Wirbelsäule.</p>
        <a class="btn-ghost" href="#">Mehr erfahren →</a>
      </div>
    </div>
  </div>
</section>
```

---

## Inhalt dieses Design-Systems

Styles/Tokens-Sync der Astro-Website `praxis-med-vital` (keine React-Komponentenbibliothek — das Klassen-Vokabular in `styles.css` ist die Komponenten-Ebene).

| Datei | Zweck |
|---|---|
| `styles.css` | Reset, Tokens, @font-face (selbst gehostet) und komplettes Klassen-Vokabular |
| `fonts/*.woff2` | Cormorant Garamond (400/500 normal, 300/400/500 kursiv) und Jost (300/400/500), Latin + Latin-Ext |
| `tokens/tokens.json` | Token-Referenz mit Verwendungszweck |
| `guidelines/design-language.md` | Design-Sprache „Warm Minimal“ |

## Token-Index

| Variable | Wert |
|---|---|
| `--cream` | `#f5f0e8` |
| `--cream-dk` | `#ede8de` |
| `--cream-dkr` | `#e2dbd0` |
| `--parchment` | `#d4c9b8` |
| `--ink` | `#1a100a` |
| `--ink-mid` | `#5a4a3c` |
| `--ink-lt` | `#9a8878` |
| `--gold` | `#c4a05a` |
| `--gold-lt` | `#c9a24a` |
| `--white` | `#faf8f4` |
| `--border` | `#ddd5c6` |
| `--sage` | `#6b5c4a` |
| `--sage-mid` | `#7d6d5a` |
| `--sage-lt` | `#eef2ec` |
| `--stone` | `#5a4d42` |
| `--stone-lt` | `#f0ebe3` |
| `--g900` | `var(--ink)` |
| `--g800` | `var(--ink)` |
| `--g700` | `var(--ink-mid)` |
| `--g600` | `var(--ink-mid)` |
| `--g100` | `var(--cream-dkr)` |
| `--g50` | `var(--cream-dk)` |
| `--amber` | `var(--gold)` |
| `--amber-dk` | `var(--gold)` |
| `--ff-serif` | `'Cormorant Garamond',Georgia,serif` |
| `--ff-sans` | `'Jost',system-ui,sans-serif` |
| `--nav-h` | `64px` |

## Klassen-Index (aus styles.css)

`.back-link`, `.btn-ghost`, `.btn-ghost--dark`, `.btn-outline`, `.btn-outline--dark`, `.btn-primary`, `.card-grid`, `.coming-soon`, `.coming-soon__badge`, `.contact-detail`, `.contact-detail__icon`, `.contact-form`, `.contact-form-wrap`, `.contact-grid`, `.container`, `.cookie-banner`, `.cookie-banner__actions`, `.cookie-banner__btn`, `.cookie-banner__btn--accept`, `.cookie-banner__btn--decline`, `.cookie-banner__text`, `.eyebrow`, `.feature`, `.feature__icon`, `.feature__text`, `.feature__title`, `.features-grid`, `.footer-bottom`, `.footer-col__brand`, `.footer-col__tagline`, `.footer-col__title`, `.footer-grid`, `.full`, `.hero`, `.hero__actions`, `.hero__content`, `.hero__eyebrow`, `.hero__image-inner`, `.hero__image-label`, `.hero__image-placeholder`, `.hero__image-sub`, `.hero__sub`, `.hero__tel`, `.hero__title`, `.hero__visual`, `.hours-table`, `.in`, `.legal-content`, `.leistung-card`, `.leistung-card__desc`, `.leistung-card__items`, `.leistung-card__num`, `.leistung-card__title`, `.leistung-grid`, `.nav`, `.nav__actions`, `.nav__backdrop`, `.nav__brand`, `.nav__cta`, `.nav__link`, `.nav__link--active`, `.nav__links`, `.nav__logo`, `.nav__menu`, `.nav__tagline`, `.nav__toggle`, `.open`, `.page-header`, `.reveal`, `.rule`, `.sec`, `.sec--cream`, `.sec--cream-dk`, `.sec--g900`, `.sec--ink`, `.sec--sage`, `.sec--sage-lt`, `.sec--stone`, `.sec--stone-lt`, `.sec--white`, `.section-sub`, `.section-title`, `.show`, `.site-footer`, `.site-header`, `.standort-card`, `.standort-card__status`, `.standort-card__status--active`, `.standort-card__status--coming-soon`, `.standort-info`, `.tag`, `.tag-list`, `.team-card`, `.team-card__avatar`, `.team-card__bio`, `.team-card__name`, `.team-card__role`, `.team-grid`, `.text-center`, `.trust-bar`, `.trust-bar__dot`, `.trust-bar__grid`, `.trust-bar__inner`, `.trust-bar__item`, `.trust-bar__number`, `.trust-bar__tel`, `.trust-bar__text`, `.two-col`, `.values-grid`
