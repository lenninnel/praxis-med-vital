# Spec: Therapie (therapie.astro) — Referenz: reference/therapie.html

## Sektionen
1. Header
2. **Hero Therapie** — Creme, padding 110px 64px 80px, Hairline unten. Riesige
   Kontur-Ziffer „01" rechts (340px, text-stroke), Wirbelsäule als Wasserzeichen (opacity .16).
   Eyebrow + H1 + Intro-Text.
3. **Therapiebereiche** — Weiß, max-width 1100. Drei aufklappbare Bereiche:
   01 Orthopädie / 02 Neurologie / 03 Spezialisierung.
   Kopfzeile: Goldverlaufs-Nummer 64px/700 + Bereichstitel; Klick toggelt (Button,
   aria-expanded), Bereiche unabhängig voneinander.
   Aufgeklappt: Liste der Therapien des Bereichs (insgesamt 27), je Zeile Name
   (Bricolage 600) + Beschreibung (Jost 300), Haarlinien-Trenner.
   WICHTIG (Fachbegriff, exakt so): „Chirotherapie n. Mutzhas" — Beschreibung
   „…nach dem Mutzhas-Konzept". Alle 27 Namen/Texte 1:1 aus der Referenz in therapien.json.
4. **CTA** — Anthrazit: „Bereit für Ihren Termin?" + Button → /kontakt.
5. Footer
