# Spec: Startseite (index.astro) — Referenz: reference/startseite.html

## Sektionsreihenfolge
1. **Header** (global.md)
2. **Hero** — Creme, Höhe 640px Desktop. Eyebrow „THERAPIE · TRAINING · COACHING" (gold-tief,
   14px, ls .3em). H1 „Kompetenz trifft auf / Leidenschaft." — Bricolage 600,
   clamp(48px,6.2vw,80px), line-height .98, ls -.03em; „Kompetenz trifft auf" nowrap;
   „Leidenschaft" im Goldverlauf (background-clip:text), Punkt anthrazit.
   Subline „Orthopädisch & neurologische Fachpraxis für Physiotherapie" (Jost 16px/300).
   Rechts oben: Wirbelsäulen-SVG (~590px, rotate 7°). Rechts: 3 Seiten-Links
   01 · Therapie / 02 · Training / 03 · Coaching (10px, 600, ls .18em, uppercase, mit
   Goldstrich) — aufsteigend, vertikal verteilt. Links unten: dunkler Viertelkreis
   (680px Kreis, anthrazit) mit weißem Kurztext + ellipsenförmigem Kontakt-Button
   (border-radius:50%, Goldverlauf, 11px/600 uppercase → /kontakt).
   Einstiegs-Animation: fadeUp (24px, .7s, gestaffelt 0/.1s/.2s).
3. **Laufband** (untere Hero-Leiste, anthrazit, volle Breite): 8 Therapien uppercase
   (Bricolage 14px/600, ls .22em, rgba(245,240,232,.85)) mit goldenen ✦-Separatoren.
   Endlos-Marquee: Inhalt dupliziert, translateX 0→-50%, 32s linear infinite.
4. **Drei Wege zu Ihrer Gesundheit** — Creme, 3 Kacheln (01 Therapie / 02 Training /
   03 Coaching): weiße Karten, 0.5px-Border anthrazit, Schatten 8px 8px 0 anthrazit,
   Goldverlaufs-Nummer, Titel 24px, Leistungsliste, Link zur Subpage.
5. **Besonderheiten** — Anthrazit, das visuelle Herzstück:
   - Oben Textband zwischen zwei Gold-Haarlinien (rgba(210,151,66,.4)):
     „Therapie, die nicht am Rezept endet · Ohne Rezept · Prävention von der Kasse
     bezuschusst · Physiofit-Partner ·" — Marquee 36s (gleiche optische Geschwindigkeit
     wie Hero-Laufband), Text gold #d29742, 13px/700, ls .22em. KEIN Goldband als
     Hintergrund — nur laufende Schrift zwischen Haarlinien.
   - Wirbelsäulen-Wasserzeichen links unten (opacity .08).
   - Eyebrow „UNSERE BESONDERHEITEN" (gold).
   - Grid 1fr 360px, gap 70px:
     **Links:** 3 Manifest-Zeilen (Bricolage 48px/800, uppercase, ls -.01em, nowrap):
     „Ohne Rezept zu uns" / „Prävention von der Kasse" / „Therapie für überall".
     Grundzustand: transparent mit 1px text-stroke rgba(250,248,244,.4).
     Aktive Zeile: Overlay-Span, absolut über der Kontur, overflow hidden,
     width 0→100% linear über 6s — Text im Goldverlauf. **Die Buchstaben selbst sind
     der Fortschrittsbalken.** Kein Glow/Schatten. Darunter Link „Sprechen Sie uns an →".
     Zeilen getrennt durch Haarlinien rgba(250,248,244,.14), padding 26px 0.
     **Rechts:** Detail-Spalte, border-left 1px rgba(210,151,66,.45), padding-left 44px.
     Inhalt der aktiven Zeile: Label (gold, 10px/600 uppercase), Beschreibung
     (Jost 14px/300, rgba(250,248,244,.92)), 3 Bullets (Goldstrich + Text, Haarlinien),
     bei Zeile 3 zusätzlich Physiofit-Logo (creme, 22px hoch) + „LIZENZIERTER PARTNER".
     Inhaltswechsel: nur Opacity-Fade .5s (kein Slide, kein Kasten).
   - **Autoplay-Logik:** Index wechselt alle 6s (synchron zur Füllung). Hover über dem
     Zeilenblock pausiert (Intervall-Flag + animation-play-state:paused). Klick auf Zeile
     wählt sie aus und startet den 6s-Takt neu. Reduced Motion: siehe global.md.
6. **Team** — Creme. H2 „Drei Inhaber. Zwei Standorte. Ein Anspruch." + Link zur Team-Seite.
   3 Karten (Foto 300px + Name 24px + Rolle-Label + Tags), Duotone-Filter s. team.md.
   Karten sind komplette Links auf /team.
7. **Standorte** — Weiß. Eyebrow „STANDORTE", H2 „2× in Ihrer Nähe.".
   2 Kacheln gemäß specs/standort-kachel.md.
8. **FAQ** — Creme, max-width 960. Eyebrow „HÄUFIGE FRAGEN". 3 aufklappbare Gruppen
   (2px-Toplinie, Gruppentitel 13px/600 uppercase + „n Fragen" + +/−; erste Gruppe
   initial offen). Fragen: Nummer (gold) + Frage (18px) + +/−; eine Frage gleichzeitig
   offen (single-open), Antwort Jost 14px/300. Alles Buttons mit aria-expanded.
9. **Kontakt-CTA** — Anthrazit mit Deko-Kreis, H2 + Ellipsen-Button.
10. **Footer** (global.md)

## Interaktions-Zusammenfassung (JS)
- Marquee/Laufband: reines CSS (keyframes translateX -50%).
- Besonderheiten: ~30 Zeilen Vanilla-JS (Index, setInterval 6s, hover pause, click select,
  reduced-motion-Guard). Füllung = CSS-Animation auf dem Overlay; Neustart beim
  Indexwechsel durch Re-Insert des Overlays oder animation-name-Toggle.
- FAQ: Gruppen-Toggle + Single-Open-Fragen, Vanilla-JS, ~20 Zeilen.
