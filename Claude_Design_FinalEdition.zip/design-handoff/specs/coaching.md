# Spec: Coaching (coaching.astro) — Referenz: reference/coaching.html

## Sektionen
1. Header
2. **Hero Coaching** — wie Therapie-Hero, Kontur-Ziffer „03", Wirbelsäule rotate 12°.
3. **Werte** — 3 Karten wie Training.
4. **Coaching-Angebote** — Weiß, max-width 1100, nummerierte Zeilen wie Trainingsleistungen
   → coaching.json.
5. **CTA** — Goldverlauf-Band „Entfalten Sie …".
6. Footer
