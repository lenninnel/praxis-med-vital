# Komponenten-Spec: Standort-Kachel (verwendet auf Startseite + Kontakt)

Es gibt KEINE eigene Standorte-Seite — die Kacheln erscheinen identisch auf
Startseite (Sektion „2× in Ihrer Nähe.") und Kontaktseite (Sektion „Unsere Standorte.").
Eine Astro-Komponente, Daten aus standorte.json.

## Aufbau
- Kachel: Anthrazit #49494a, KEIN Border-Radius, Schatten 8px 8px 0 var(--gold-tief),
  KEINE Fotos. Wirbelsäulen-SVG als Wasserzeichen rechts unten (opacity .3, rotate 10°,
  overflow hidden). Padding 44–48px.
- **Wörth am Main (aktiv):** Name (Bricolage 28–30px/600, rgba(240,235,225,.94)),
  Adresse (Jost 14px/300, rgba(240,235,225,.6)), Telefon als tel:-Link
  (Bricolage 17–18px/600, hell), Mail als mailto: (Jost 13px/300),
  Zusatzzeile „Parkplätze direkt vor der Praxis · barrierefreier Zugang" (nur Kontaktseite),
  Startseite stattdessen Link „Standort ansehen →" (gold, 10px/600 uppercase).
- **Erlenbach am Main (kommend):** Badge „BALD VERFÜGBAR" (Goldverlauf-Fläche, weiß,
  9px/600, ls .22em, padding 6px 14px), Name, Beschreibungstext, Link
  („Mehr erfahren →" bzw. mailto „Auf dem Laufenden bleiben →").
- Grid: 2 Spalten (minmax(0,1fr)), gap 40px; mobil 1 Spalte.
