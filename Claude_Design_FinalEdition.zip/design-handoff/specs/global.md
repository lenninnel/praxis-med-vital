# Global: Header, Footer, Breakpoints, A11y, Motion

## Header (alle Seiten identisch)
- Weißer/cremer Balken (#f5f0e8), Höhe ~72px, Hairline unten (--hairline-dunkel).
- Links: Bildmarke (Kreis mit Wirbelsäule, ~40px) + Wortmarke „med.vital" (anthrazit/gold).
- Rechts: Nav-Links THERAPIE · TRAINING · COACHING · TEAM · KONTAKT —
  Bricolage 12px, weight 600, letter-spacing .14em, uppercase, Farbe #49494a.
  Hover: #975e26. Aktive Seite: #975e26 + 2px Goldunterstrich.
- Mobil (<768): Bildmarke + Burger; Overlay-Menü vollflächig Anthrazit, Links Creme 24px.

## Footer (alle Seiten identisch)
- Anthrazit #49494a, Hairline oben (--hairline-hell), padding 72px 40px 0.
- Grid 2fr 1fr 1fr 1fr: (1) Marke + Tagline, (2) „Praxis"-Links, (3) Leistungen, (4) Kontakt.
- Spaltentitel: 10px, 600, ls .22em, uppercase, rgba(240,235,225,.45).
- Links: Jost 13px, 300, rgba(240,235,225,.6); Hover #d29742.
- Bottom-Bar: Copyright + Impressum/Datenschutz, Hairline oben.

## Breakpoints (Prototypen sind Desktop-only — dies ist die Vorgabe)
- **≥1200px:** wie Referenz-HTML (Inhaltbreite 1280px zentriert).
- **768–1199px:** 3er-Grids → 2 Spalten (Team, Werte), 2er-Grids bleiben; Besonderheiten:
  Detail-Spalte rutscht UNTER die Manifest-Zeilen (volle Breite, Haarlinie oben statt links);
  Manifest-Zeilen 40px; Hero: Seiten-Links (01–03) entfallen, Wirbelsäule kleiner/transparenter.
- **<768px:** alle Grids 1 Spalte; Hero H1 clamp bis 44px; Laufband bleibt (Text 12px);
  Manifest-Zeilen 30–34px, Umbruch erlaubt (white-space normal), Buchstaben-Füllung
  funktioniert identisch; Standort-/Team-Karten gestapelt; FAQ unverändert (volle Breite).
- Nichts horizontal scrollen lassen; Offset-Schatten (8px) auf Mobil auf 6px reduzieren.

## Fokus-States (verbindlich, global)
```css
:focus-visible { outline: 2px solid var(--gold-tief); outline-offset: 3px; }
.auf-dunkel :focus-visible,
[data-dark] :focus-visible { outline-color: var(--gold); }
```
- Alle klickbaren Nicht-Links (FAQ-Zeilen, Besonderheiten-Zeilen, Therapiebereich-Toggles)
  als <button> (volle Breite, text-align inherit) umsetzen — nicht als <div onclick>.
- Akkordeons: aria-expanded am Button, aria-controls auf den Inhalt; Inhalt mit hidden.
- Autoplay-Index (Besonderheiten): Zeilen sind Buttons mit role="tab"-Semantik optional;
  mindestens: Tastatur erreichbar, Enter/Space wählt aus, Auswahl stoppt Autoplay-Takt neu.

## Kontrast (gemessen auf die Tokenfarben, WCAG 2.1)
| Kombination | Ratio | Bewertung |
|---|---|---|
| #faf8f4 auf #49494a | ≈ 8,7:1 | AA + AAA, überall ok |
| #5c5c5e auf #f5f0e8 | ≈ 5,3:1 | AA Fließtext ok |
| #49494a auf #f5f0e8 | ≈ 7,9:1 | AA + AAA |
| #975e26 auf #f5f0e8 | ≈ 4,7:1 | AA normal knapp ok; für Labels ≥10px/600 ok |
| #d29742 auf #49494a | ≈ 4,6:1 | AA für Großtext/Labels; NICHT für langen Fließtext |
| #faf8f4 auf Verlauf (#d29742-Ende) | ≈ 2,3:1 | nur Großtext ≥24px/600 (CTA-Bänder) — Buttontexte auf Verlauf immer ≥14px/600 uppercase + zusätzlich Unterstreichung/Hover |
| rgba(240,235,225,.6) auf #49494a | ≈ 5,2:1 | AA ok (Footer-/Adresstext) |
- Goldverlauf-Text (background-clip) nur für dekorative Headlines verwenden, nie für
  bedeutungstragende kleine Texte.

## Bewegung & prefers-reduced-motion (verbindlich)
Alle Animationen in einem Media-Query-Block deaktivieren:
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; }
}
```
Zusätzlich verhaltensseitig:
- **Laufband/Marquee:** steht still; eine Textzeile sichtbar, overflow hidden (kein JS nötig).
- **Besonderheiten-Autoplay:** setInterval NICHT starten, wenn
  `matchMedia('(prefers-reduced-motion: reduce)').matches` — erste Zeile aktiv/gefüllt,
  Wechsel nur per Klick, Füllung erscheint sofort (width:100%).
- **fadeUp-Entrances (Hero):** Elemente sofort sichtbar.
- **FAQ/Akkordeon:** Inhalt ohne Transition ein-/ausblenden.
