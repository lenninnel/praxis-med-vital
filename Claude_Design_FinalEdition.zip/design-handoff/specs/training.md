# Spec: Training (training.astro) — Referenz: reference/training.html

## Sektionen
1. Header
2. **Hero Training** — wie Therapie-Hero, Kontur-Ziffer „02", Wirbelsäule rotate -6°.
3. **Werte** — Creme, 3 kleine Karten (weiß, 0.5px-Border, Schatten 6px 6px 0 anthrazit).
4. **Trainingsleistungen** — Weiß, max-width 1100. 6 Zeilen im Grid 90px 340px 1fr:
   Goldverlaufs-Nummer 30px/700 (160°-Verlauf), Titel 22px/600, Beschreibung (Jost 14px/300).
   01 Präventionstraining (§20 SGB V) … 05 Neurologisches Zirkeltraining ·
   06 Freies Training — Reihenfolge/Texte exakt aus Referenz → trainingsleistungen.json.
5. **Trainingsfläche** — Anthrazit, Grid 1fr 1fr, Wirbelsäulen-Wasserzeichen (opacity .18).
6. **CTA** — Goldverlauf-Band „Starten Sie …" (Kontrastregel: nur Großtext, s. global.md).
7. Footer
