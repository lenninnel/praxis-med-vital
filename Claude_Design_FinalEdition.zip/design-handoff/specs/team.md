# Spec: Team (team.astro) — Referenz: reference/team.html

## Sektionen
1. Header
2. **Hero Team** — Creme, Wirbelsäule rechts (opacity .16), Eyebrow + H1.
3. **Philosophie** — Anthrazit, zentriert (max-width 900), Wirbelsäulen-Wasserzeichen.
4. **Profile** — Creme, max-width 1180, 3 große Zeilen im Wechsel-Grid (420px 1fr / 1fr 420px):
   Goldverlaufs-Nummer 44px/700, Name 38px/600, Rolle-Label (gold-tief, 11px/600, ls .2em,
   uppercase), Bio (Jost 14px/300, max 520px), Tag-Chips (9px/600 uppercase, 0.5px-Border).
   Porträt: 440px hoch, 0.5px-Border, Schatten 8px 8px 0 anthrazit.
   Inhaber: Sven Wehrheim · Christoph Kenner („Physiotherapeut · Heilpraktiker") · Kai Hurth.
5. **Karriere** — Goldverlauf-Band mit CTA.
6. Footer

## Porträt-Duotone (alle 3 Porträts, per CSS — Originale unbearbeitet lassen)
```css
.portrait img {
  object-fit: cover; object-position: center 20%; /* je Porträt anpassen, s. Referenz */
  filter: grayscale(.55) sepia(.28) saturate(1.05) contrast(.96) brightness(1.02);
}
.portrait::after {
  content:''; position:absolute; inset:0; pointer-events:none;
  background: linear-gradient(160deg, rgba(210,151,66,.18), rgba(151,94,38,.22));
  mix-blend-mode: multiply;
}
```
