# Spec: Kontakt (kontakt.astro) — Referenz: reference/kontakt.html

## Sektionen
1. Header
2. **Hero Kontakt** — Creme: Eyebrow, H1 (clamp bis 80px), Text „Am schnellsten erreichen
   Sie uns telefonisch…", direkte Tel/Mail-Links, Wirbelsäule rechts (opacity .16).
3. **Öffnungszeiten** — Anthrazit, Grid 3 Spalten (Zeiten + Hinweise), Daten aus
   oeffnungszeiten.json.
4. **Standorte** — Weiß, H2 „Unsere Standorte." — Kacheln gemäß specs/standort-kachel.md
   (gleiche Komponente wie Startseite!).
5. **FAQ** — identisch zur Startseiten-FAQ (gleiche Komponente + faq.json: 3 Gruppen,
   14 Fragen, erste Gruppe offen, Fragen single-open).
6. **CTA** — Goldverlauf-Band „Wir freuen uns auf Sie."
7. Footer

## Hinweis Formular
Der Prototyp enthält KEIN Kontaktformular — Kontakt läuft über Tel/Mail. Falls später
gewünscht: eigenes Feature (Spam-Schutz, Zustellung), nicht Teil dieses Handoffs.
