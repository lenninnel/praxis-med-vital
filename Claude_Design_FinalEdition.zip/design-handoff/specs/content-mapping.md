# Content-Mapping: Daten-Dateien vs. hartkodiert

## In Daten-Dateien auslagern (src/data/)
| Datei | Inhalt | verwendet auf |
|---|---|---|
| therapien.json | 3 Bereiche (Orthopädie/Neurologie/Spezialisierung) mit allen 27 Therapien: {bereich, nummer, therapien: [{name, beschreibung}]} | therapie |
| laufband.json | 8 Therapien fürs Hero-Ticker-Band (Manuelle Therapie … Atlas Therapie) | startseite |
| besonderheiten.json | 3 Einträge: {zeile, label, beschreibung, bullets[], physiofit: bool} | startseite |
| faq.json | 3 Gruppen (Rezept, Kosten & Privatzahler / Termine & Ablauf / Training & Nachsorge), 14 Fragen: {gruppe, frage, antwort} | startseite, kontakt (identisch — eine Quelle!) |
| team.json | 3 Inhaber: {name, rolle, bio, tags[], portrait} | startseite (Kurzform), team (Langform) |
| standorte.json | Wörth (Adresse, Tel, Mail, Hinweise) + Erlenbach (Status „Bald verfügbar", Text) | startseite, kontakt |
| trainingsleistungen.json | 6 Leistungen (01 Präventionstraining §20 … 06 Freies Training) | training |
| coaching.json | Coaching-Angebote | coaching |
| oeffnungszeiten.json | Zeiten je Standort | kontakt |

## Hartkodiert in den Seiten/Komponenten (bewusst)
- Hero-Claim „Kompetenz trifft auf Leidenschaft." + Subline (startseite)
- Sektions-Headlines und Eyebrows („Unsere Besonderheiten", „Drei Inhaber. Zwei Standorte.
  Ein Anspruch.", „2× in Ihrer Nähe." …)
- CTA-Band-Texte (je Seite individuell)
- Marquee-Text Besonderheiten („Therapie, die nicht am Rezept endet · …")
- Footer-Tagline, Nav-Beschriftungen
- Physiofit-Partnerzeile „Lizenzierter Physiofit-Partner"

## Wichtige Datenregeln
- FAQ existiert EINMAL (faq.json) und wird auf Startseite und Kontakt identisch gerendert.
- Telefonnummer 09372 – 139 444 und Mail info@therapie-woerth.com nur in standorte.json
  pflegen; überall referenzieren (Hero-Button, Kontakt, Footer, Standort-Kacheln).
- Erlenbach: Eröffnung/Adresse offen — Status-Feld in standorte.json steuert Badge + Text.
