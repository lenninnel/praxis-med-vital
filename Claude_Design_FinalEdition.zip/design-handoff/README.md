# Design-Handoff: med.vital Website — Richtung D „Expressiv"

## Überblick
Kompletter Website-Auftritt der Praxis med.vital (Physiotherapie, Wörth am Main + Erlenbach am Main):
Startseite + 5 Subpages. Leitmotiv: Wirbelsäule, Anthrazit/Creme mit Goldverlauf-Akzent,
Bricolage Grotesque (Display) + Jost (Text), border-radius 0, harte Offset-Schatten.

## Über die Design-Dateien
Die Dateien in `reference/` sind **Design-Referenzen in HTML** — Prototypen, die Aussehen und
Verhalten zeigen. Sie sind NICHT der Produktionscode und werden nicht deployed. Aufgabe ist,
diese Designs im Ziel-Stack neu zu bauen. Maße, Farben und Texte in den Specs sind verbindlich;
im Zweifel gilt die Referenz-HTML (dort stehen alle Werte inline im Markup).

## Fidelity
**High-fidelity.** Farben, Typografie, Abstände, Texte und Interaktionen sind final und
pixelgenau umzusetzen. Nur das responsive Verhalten unterhalb 1200px ist als Vorgabe in
`specs/global.md` beschrieben (die Prototypen sind Desktop-only, min-width 1280px).

## Ziel-Stack (verbindlich)
- **Astro 7** (Node 22+), rein statisch (`output: 'static'`), keine UI-Framework-Islands nötig —
  die wenigen Interaktionen sind Vanilla-JS in kleinen Inline-Scripts oder einer `site.js`.
- **Deployment: Cloudflare Workers Static Assets** (Assets-Binding, kein Pages). Astro-Build
  nach `dist/`, Worker liefert statisch aus.
- **KEIN Tailwind.** Plain CSS mit Custom Properties und Cascade Layers:
  `@layer reset, tokens, base, layout, components, utilities;`
  Tokens: `tokens/tokens.css` aus diesem Paket unverändert übernehmen (Layer `tokens`).
- Fonts selbst hosten (siehe `assets/fonts/` + Lizenzhinweis unten). Kein Google-Fonts-CDN
  in Produktion (DSGVO).

## Paketstruktur
```
design-handoff/
  README.md               ← diese Datei
  tokens/tokens.css       ← alle Design-Tokens als Custom Properties
  specs/
    global.md             ← Header/Footer, Breakpoints, Fokus, Kontrast, Reduced Motion
    startseite.md … kontakt.md  (eine Spec pro Seite)
    content-mapping.md    ← was aus Daten-Dateien kommt, was hartkodiert ist
  reference/              ← 6 eigenständige HTML-Dateien (visuelle Referenz, offline lauffähig)
  assets/
    logos/                ← med.vital Logos + Wirbelsäulen-Grafik
    physiofit/            ← Physiofit-Logo (Original + eingefärbte Varianten)
    portraits/            ← 3 Inhaber-Porträts (Duotone entsteht per CSS-Filter, s. team.md)
    fonts/                ← Jost woff2 (Bricolage Grotesque: selbst von Google Fonts beziehen)
```

## Empfohlene Umsetzung in Astro
- Eine Layout-Komponente (`BaseLayout.astro`) mit Header + Footer (identisch auf allen Seiten,
  Spec in `specs/global.md`).
- Seiten: `index.astro`, `therapie.astro`, `training.astro`, `coaching.astro`, `team.astro`, `kontakt.astro`.
- Inhalte gemäß `specs/content-mapping.md` in `src/data/*.json` auslagern.
- Wiederkehrende Bausteine als Astro-Komponenten: SectionEyebrow, CtaBand, StandortKachel,
  TeamKarte, Faq (mit Vanilla-JS), Laufband, Besonderheiten (mit Vanilla-JS).

## Assets & Zielpfade (Vorschlag: public/)
| Datei im Paket | Zielpfad | Verwendung |
|---|---|---|
| assets/logos/medvital-logo-voll-hell.svg | public/logos/ | Logo-Variante hell (dunkle Flächen) |
| assets/logos/medvital-wortmarke.svg | public/logos/ | Wortmarke „med.vital" |
| assets/logos/medvital-bildmarke.svg | public/logos/ | Bildmarke (Kreis + Wirbelsäule), Header |
| assets/logos/medvital-wirbelsaeule.svg | public/logos/ | Wirbelsäulen-Grafik — Wasserzeichen auf fast jeder Seite |
| assets/physiofit/physiofit-logo-original.svg | public/partner/ | Original (Blue Dark) — nur auf hellem Grund |
| assets/physiofit/physiofit-logo-creme.svg | public/partner/ | eingefärbt #faf8f4 — auf Anthrazit (Besonderheiten) |
| assets/physiofit/physiofit-logo-anthrazit.svg | public/partner/ | eingefärbt #49494a — auf Creme |
| assets/portraits/sven-wehrheim.jpg | public/team/ | Porträt (Original, Duotone per CSS) |
| assets/portraits/kai-hurth.jpg | public/team/ | Porträt |
| assets/portraits/christoph-kenner.jpg | public/team/ | Porträt |
| assets/fonts/*.woff2 | public/fonts/ | Jost 300/400/500 (latin + latin-ext) |

## Fonts & Lizenz
- **Jost** (300/400/500): woff2 liegt bei. Lizenz: SIL Open Font License 1.1.
- **Bricolage Grotesque** (400–800, variabel): liegt NICHT bei — von Google Fonts
  herunterladen und selbst hosten (https://fonts.google.com/specimen/Bricolage+Grotesque).
  Lizenz: SIL Open Font License 1.1. Die Prototypen laden sie per Google-CDN; in Produktion
  self-hosted als woff2 mit `font-display: swap`.
- OFL erlaubt Einbettung und Self-Hosting; Lizenztext den Fonts beilegen
  (https://openfontlicense.org). Kein Verkauf der Fontdateien allein.

## Externe Verweise
- Physiofit-Partnerschaft: https://physiofit.app/ (Logo-Nutzung als lizenzierter Partner
  mit Physiofit abstimmen, falls noch nicht geschehen).
- §20-Zertifizierung Gerätetraining: Partner SVG Germany (https://www.svggermany.de).
